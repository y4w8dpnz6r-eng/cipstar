# Build guide
Requirements: macOS 14+, Xcode 15.4+ (16 recommended).

1. `brew install xcodegen`
2. In the project root: `xcodegen generate` -> creates `CipStar.xcodeproj` from `project.yml`.
3. `open CipStar.xcodeproj`, select the CipStar target > Signing & Capabilities: choose YOUR team; change bundle id `com.cipstar.app` if taken.
4. Run on a real device (video editing on the simulator is limited).
5. Run Core tests (no device needed): `cd Packages/CipStarKit && swift test`
6. IPA: `./scripts/build_ipa.sh YOUR_TEAM_ID` (or Xcode: Product > Archive > Distribute App). Output: `build/ipa/CipStar.ipa`.

If the build reports errors, send me the exact messages and I will fix them.
