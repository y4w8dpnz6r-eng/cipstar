# Architecture
- `Packages/CipStarKit/CipStarCore` — models (Project, Clip), timeline operations (split/trim/speed/move/duplicate), UndoStack, ProjectRepository (atomic JSON save, backup fallback, media copied into project, never modifies originals), StorageMonitor. Pure Foundation, unit-tested.
- `CipStarVideoEngine` — CompositionBuilder (Project -> AVMutableComposition + video composition + audio mix, shared by preview and export), VideoExporter (AVAssetExportSession, H.264/HEVC, MP4/MOV, 720p/1080p/4K, 24–60 fps, cancel, progress).
- `CipStar` app target — SwiftUI: HomeView, EditorView (preview, timeline, tools), ExportSheet; EN/AR localization (RTL), dark/light theme.
Further engines (Effects, Audio, Photo, Plugin, AI) will be added as new package targets.
