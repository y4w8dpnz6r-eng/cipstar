import Foundation

/// Stores projects on disk: Projects/<uuid>/project.json (+ .bak) and Projects/<uuid>/Media/.
/// Writes are atomic; the previous version is kept as a backup and used if the main file is corrupt.
/// Original media is copied into the project folder and never modified.
public final class ProjectRepository: @unchecked Sendable {
    public let root: URL
    private let fm = FileManager.default

    public init(root: URL? = nil) {
        let base = root ?? FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Projects", isDirectory: true)
        self.root = base
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
    }

    private var encoder: JSONEncoder { let e = JSONEncoder(); e.dateEncodingStrategy = .iso8601; return e }
    private var decoder: JSONDecoder { let d = JSONDecoder(); d.dateDecodingStrategy = .iso8601; return d }

    public func projectDir(_ id: UUID) -> URL { root.appendingPathComponent(id.uuidString, isDirectory: true) }
    private func file(_ id: UUID) -> URL { projectDir(id).appendingPathComponent("project.json") }
    private func backup(_ id: UUID) -> URL { projectDir(id).appendingPathComponent("project.json.bak") }
    public func mediaURL(projectID: UUID, file: String) -> URL {
        projectDir(projectID).appendingPathComponent("Media", isDirectory: true).appendingPathComponent(file)
    }

    public func save(_ project: Project) throws {
        let dir = projectDir(project.id)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let data = try encoder.encode(project)
        let main = file(project.id)
        if fm.fileExists(atPath: main.path) {
            try? fm.removeItem(at: backup(project.id))
            try? fm.copyItem(at: main, to: backup(project.id))
        }
        try data.write(to: main, options: .atomic)
    }

    public func load(_ id: UUID) throws -> Project {
        if let data = try? Data(contentsOf: file(id)), let p = try? decoder.decode(Project.self, from: data) { return p }
        let data = try Data(contentsOf: backup(id))      // fallback to last good version
        return try decoder.decode(Project.self, from: data)
    }

    /// Unreadable projects are skipped instead of crashing the app.
    public func list() -> [Project] {
        let dirs = (try? fm.contentsOfDirectory(at: root, includingPropertiesForKeys: nil)) ?? []
        return dirs.compactMap { UUID(uuidString: $0.lastPathComponent) }
            .compactMap { try? load($0) }
            .sorted { $0.modifiedAt > $1.modifiedAt }
    }

    public func delete(_ id: UUID) { try? fm.removeItem(at: projectDir(id)) }

    @discardableResult
    public func duplicate(_ id: UUID, newName: String) throws -> Project {
        var p = try load(id)
        let newID = UUID()
        try fm.copyItem(at: projectDir(id), to: projectDir(newID))
        p.id = newID; p.name = newName; p.createdAt = Date(); p.modifiedAt = Date()
        try save(p)
        return p
    }

    /// Copies a picked file into the project's Media folder and returns the stored file name.
    public func importMedia(from src: URL, projectID: UUID) throws -> String {
        let dir = projectDir(projectID).appendingPathComponent("Media", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let name = UUID().uuidString + (src.pathExtension.isEmpty ? "" : "." + src.pathExtension)
        try fm.copyItem(at: src, to: dir.appendingPathComponent(name))
        return name
    }
}

public enum StorageMonitor {
    public static func availableBytes() -> Int64 {
        let url = URL(fileURLWithPath: NSHomeDirectory())
        let v = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        return v?.volumeAvailableCapacityForImportantUsage ?? Int64.max
    }
}
