import Foundation

/// A segment of a source media file placed on the timeline (non-destructive: the file is never modified).
public struct Clip: Codable, Identifiable, Hashable, Sendable {
    public var id: UUID
    public var mediaFile: String        // file name inside the project's Media folder
    public var sourceStart: Double      // seconds into the source
    public var sourceDuration: Double   // seconds of source used
    public var speed: Double            // 1.0 = normal
    public var volume: Double           // 0...1

    public init(id: UUID = UUID(), mediaFile: String, sourceStart: Double = 0,
                sourceDuration: Double, speed: Double = 1, volume: Double = 1) {
        self.id = id; self.mediaFile = mediaFile; self.sourceStart = sourceStart
        self.sourceDuration = sourceDuration; self.speed = speed; self.volume = volume
    }

    /// Length on the timeline after speed change.
    public var timelineDuration: Double { sourceDuration / max(speed, 0.01) }
}

public struct Project: Codable, Identifiable, Hashable, Sendable {
    public var id: UUID
    public var name: String
    public var createdAt: Date
    public var modifiedAt: Date
    public var clips: [Clip]
    public var schemaVersion: Int

    public init(id: UUID = UUID(), name: String, clips: [Clip] = []) {
        self.id = id; self.name = name; self.clips = clips
        self.createdAt = Date(); self.modifiedAt = Date(); self.schemaVersion = 1
    }

    public var duration: Double { clips.reduce(0) { $0 + $1.timelineDuration } }
}
