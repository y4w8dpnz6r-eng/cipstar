import Foundation

public extension Project {
    /// Finds the clip under a timeline time. `offset` is timeline seconds from the clip's start.
    func locate(_ t: Double) -> (index: Int, offset: Double)? {
        var acc = 0.0
        for (i, c) in clips.enumerated() {
            let d = c.timelineDuration
            if t < acc + d || (i == clips.count - 1 && t <= acc + d) { return (i, max(0, t - acc)) }
            acc += d
        }
        return nil
    }

    @discardableResult
    mutating func split(at t: Double, minPiece: Double = 0.1) -> Bool {
        guard let loc = locate(t) else { return false }
        let c = clips[loc.index]
        guard loc.offset >= minPiece, c.timelineDuration - loc.offset >= minPiece else { return false }
        let srcOffset = loc.offset * c.speed
        var a = c; a.sourceDuration = srcOffset
        var b = c; b.id = UUID(); b.sourceStart = c.sourceStart + srcOffset; b.sourceDuration = c.sourceDuration - srcOffset
        clips.replaceSubrange(loc.index...loc.index, with: [a, b])
        return true
    }

    /// Removes the part of the clip before the playhead.
    @discardableResult
    mutating func trimHead(at t: Double, minPiece: Double = 0.1) -> Bool {
        guard let loc = locate(t) else { return false }
        var c = clips[loc.index]
        guard loc.offset > 0, c.timelineDuration - loc.offset >= minPiece else { return false }
        let srcOffset = loc.offset * c.speed
        c.sourceStart += srcOffset; c.sourceDuration -= srcOffset
        clips[loc.index] = c
        return true
    }

    /// Removes the part of the clip after the playhead.
    @discardableResult
    mutating func trimTail(at t: Double, minPiece: Double = 0.1) -> Bool {
        guard let loc = locate(t) else { return false }
        var c = clips[loc.index]
        guard loc.offset >= minPiece else { return false }
        c.sourceDuration = min(c.sourceDuration, loc.offset * c.speed)
        clips[loc.index] = c
        return true
    }

    mutating func remove(_ id: UUID) { clips.removeAll { $0.id == id } }

    @discardableResult
    mutating func duplicate(_ id: UUID) -> UUID? {
        guard let i = clips.firstIndex(where: { $0.id == id }) else { return nil }
        var copy = clips[i]; copy.id = UUID()
        clips.insert(copy, at: i + 1)
        return copy.id
    }

    mutating func move(_ id: UUID, by delta: Int) {
        guard let i = clips.firstIndex(where: { $0.id == id }) else { return }
        let j = min(max(i + delta, 0), clips.count - 1)
        guard i != j else { return }
        clips.insert(clips.remove(at: i), at: j)
    }

    mutating func setSpeed(_ id: UUID, _ speed: Double) {
        guard let i = clips.firstIndex(where: { $0.id == id }) else { return }
        clips[i].speed = min(max(speed, 0.1), 16)
    }

    mutating func setVolume(_ id: UUID, _ volume: Double) {
        guard let i = clips.firstIndex(where: { $0.id == id }) else { return }
        clips[i].volume = min(max(volume, 0), 1)
    }
}

/// Snapshot-based undo/redo.
public struct UndoStack<T> {
    private var undoStack: [T] = []
    private var redoStack: [T] = []
    public init() {}
    public var canUndo: Bool { !undoStack.isEmpty }
    public var canRedo: Bool { !redoStack.isEmpty }

    /// Call with the state *before* a change.
    public mutating func record(_ state: T) {
        undoStack.append(state); redoStack.removeAll()
        if undoStack.count > 200 { undoStack.removeFirst() }
    }
    public mutating func undo(current: T) -> T? {
        guard let prev = undoStack.popLast() else { return nil }
        redoStack.append(current); return prev
    }
    public mutating func redo(current: T) -> T? {
        guard let next = redoStack.popLast() else { return nil }
        undoStack.append(current); return next
    }
}

public enum TimeFormat {
    public static func timecode(_ seconds: Double, fps: Int = 30) -> String {
        let s = max(0, seconds.isFinite ? seconds : 0)
        let total = Int(s)
        let frames = Int((s - Double(total)) * Double(fps))
        return String(format: "%02d:%02d.%02d", total / 60, total % 60, frames)
    }
}
