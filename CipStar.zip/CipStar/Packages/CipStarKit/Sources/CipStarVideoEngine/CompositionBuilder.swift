import AVFoundation
import CipStarCore

public struct BuiltComposition {
    public let composition: AVMutableComposition
    public let videoComposition: AVMutableVideoComposition
    public let audioMix: AVAudioMix
    public let duration: Double
    public let renderSize: CGSize
    /// Clips skipped because their media file is missing or has no video track.
    public let missingClipIDs: [UUID]
}

public enum BuildError: LocalizedError {
    case allMediaMissing
    public var errorDescription: String? { "The media files of this project could not be found." }
}

/// Turns a `Project` into a real AVFoundation composition used by BOTH the preview and the export.
public enum CompositionBuilder {
    private struct Prepared {
        let clip: Clip; let asset: AVURLAsset
        let video: AVAssetTrack; let audio: AVAssetTrack?
        let natural: CGSize; let preferred: CGAffineTransform
    }

    public static func build(project: Project,
                             mediaURL: @Sendable (Clip) -> URL,
                             longSide: Int,
                             frameRate: Int) async throws -> BuiltComposition? {
        guard !project.clips.isEmpty else { return nil }

        var missing: [UUID] = []
        var prepared: [Prepared] = []
        for clip in project.clips {
            let url = mediaURL(clip)
            guard FileManager.default.fileExists(atPath: url.path) else { missing.append(clip.id); continue }
            let asset = AVURLAsset(url: url)
            guard let v = try await asset.loadTracks(withMediaType: .video).first else { missing.append(clip.id); continue }
            let a = try await asset.loadTracks(withMediaType: .audio).first
            let (n, p) = try await v.load(.naturalSize, .preferredTransform)
            prepared.append(Prepared(clip: clip, asset: asset, video: v, audio: a, natural: n, preferred: p))
        }
        guard let first = prepared.first else { throw BuildError.allMediaMissing }

        // Canvas follows the orientation of the first clip (16:9 or 9:16).
        let o = CGRect(origin: .zero, size: first.natural).applying(first.preferred)
        let portrait = abs(o.height) > abs(o.width)
        let long = CGFloat(longSide)
        let short = CGFloat(Int(long * 9 / 16 / 2) * 2)
        let canvas = portrait ? CGSize(width: short, height: long) : CGSize(width: long, height: short)

        let comp = AVMutableComposition()
        guard let vTrack = comp.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
              let aTrack = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
        else { return nil }

        let mixParams = AVMutableAudioMixInputParameters(track: aTrack)
        var instructions: [AVMutableVideoCompositionInstruction] = []
        var cursor = CMTime.zero

        for item in prepared {
            let src = CMTimeRange(start: CMTime(seconds: item.clip.sourceStart, preferredTimescale: 600),
                                  duration: CMTime(seconds: item.clip.sourceDuration, preferredTimescale: 600))
            try vTrack.insertTimeRange(src, of: item.video, at: cursor)
            if let a = item.audio { try aTrack.insertTimeRange(src, of: a, at: cursor) }

            let inserted = CMTimeRange(start: cursor, duration: src.duration)
            let newDuration = CMTime(seconds: item.clip.timelineDuration, preferredTimescale: 600)
            if abs(item.clip.speed - 1) > 0.001 { comp.scaleTimeRange(inserted, toDuration: newDuration) }

            mixParams.setVolume(Float(item.clip.volume), at: cursor)

            let layer = AVMutableVideoCompositionLayerInstruction(assetTrack: vTrack)
            layer.setTransform(fit(natural: item.natural, preferred: item.preferred, into: canvas), at: cursor)
            let inst = AVMutableVideoCompositionInstruction()
            inst.timeRange = CMTimeRange(start: cursor, duration: newDuration)
            inst.layerInstructions = [layer]
            instructions.append(inst)

            cursor = cursor + newDuration
        }

        let vc = AVMutableVideoComposition()
        vc.renderSize = canvas
        vc.frameDuration = CMTime(value: 1, timescale: CMTimeScale(frameRate))
        vc.instructions = instructions

        let mix = AVMutableAudioMix()
        mix.inputParameters = [mixParams]

        return BuiltComposition(composition: comp, videoComposition: vc, audioMix: mix,
                                duration: cursor.seconds, renderSize: canvas, missingClipIDs: missing)
    }

    /// Aspect-fit transform honoring the track's preferred (rotation) transform.
    static func fit(natural: CGSize, preferred: CGAffineTransform, into target: CGSize) -> CGAffineTransform {
        let rect = CGRect(origin: .zero, size: natural).applying(preferred)
        let w = abs(rect.width), h = abs(rect.height)
        let scale = min(target.width / w, target.height / h)
        var t = preferred
        t = t.concatenating(CGAffineTransform(translationX: -rect.minX, y: -rect.minY))
        t = t.concatenating(CGAffineTransform(scaleX: scale, y: scale))
        t = t.concatenating(CGAffineTransform(translationX: (target.width - w * scale) / 2,
                                              y: (target.height - h * scale) / 2))
        return t
    }
}
