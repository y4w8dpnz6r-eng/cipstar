import AVFoundation
import CipStarCore

public struct ExportSettings: Equatable, Sendable {
    public enum Resolution: Int, CaseIterable, Sendable {
        case p720 = 1280, p1080 = 1920, p2160 = 3840
        public var title: String { self == .p720 ? "720p" : self == .p1080 ? "1080p" : "4K UHD" }
    }
    public enum Codec: CaseIterable, Sendable { case h264, hevc
        public var title: String { self == .h264 ? "H.264" : "HEVC (H.265)" } }
    public enum Container: CaseIterable, Sendable { case mp4, mov
        public var title: String { self == .mp4 ? "MP4" : "MOV" } }

    public static let frameRates = [24, 25, 30, 50, 60]
    public var resolution: Resolution = .p1080
    public var fps: Int = 30
    public var codec: Codec = .hevc
    public var container: Container = .mp4
    public init() {}
}

public enum ExportError: LocalizedError {
    case emptyProject, cannotCreateSession, cancelled
    public var errorDescription: String? {
        switch self {
        case .emptyProject: return "The project has no clips."
        case .cannotCreateSession: return "This device cannot export with the chosen settings."
        case .cancelled: return "Export cancelled."
        }
    }
}

/// Renders the same composition used for preview at the chosen resolution / frame rate (no hidden downscaling, no watermark).
public final class VideoExporter: @unchecked Sendable {
    private var session: AVAssetExportSession?
    public init() {}

    public func cancel() { session?.cancelExport() }

    public func export(project: Project,
                       mediaURL: @escaping @Sendable (Clip) -> URL,
                       settings: ExportSettings,
                       progress: @escaping @Sendable (Double) -> Void) async throws -> URL {
        guard let built = try await CompositionBuilder.build(project: project, mediaURL: mediaURL,
                                                             longSide: settings.resolution.rawValue,
                                                             frameRate: settings.fps)
        else { throw ExportError.emptyProject }

        let preferred = settings.codec == .hevc ? AVAssetExportPresetHEVCHighestQuality : AVAssetExportPresetHighestQuality
        guard let s = AVAssetExportSession(asset: built.composition, presetName: preferred)
                ?? AVAssetExportSession(asset: built.composition, presetName: AVAssetExportPresetHighestQuality)
        else { throw ExportError.cannotCreateSession }

        let ext = settings.container == .mp4 ? "mp4" : "mov"
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("CipStar-\(UUID().uuidString)").appendingPathExtension(ext)
        s.outputURL = url
        s.outputFileType = settings.container == .mp4 ? .mp4 : .mov
        s.videoComposition = built.videoComposition
        s.audioMix = built.audioMix
        s.audioTimePitchAlgorithm = .spectral
        session = s

        let poll = Task {
            while !Task.isCancelled {
                progress(Double(s.progress))
                try? await Task.sleep(nanoseconds: 150_000_000)
            }
        }
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            s.exportAsynchronously { c.resume() }
        }
        poll.cancel()
        session = nil

        switch s.status {
        case .completed: progress(1); return url
        case .cancelled: try? FileManager.default.removeItem(at: url); throw ExportError.cancelled
        default: try? FileManager.default.removeItem(at: url); throw s.error ?? ExportError.cannotCreateSession
        }
    }
}
