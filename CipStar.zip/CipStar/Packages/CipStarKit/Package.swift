// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "CipStarKit",
    platforms: [.iOS(.v17), .macOS(.v14)],
    products: [
        .library(name: "CipStarCore", targets: ["CipStarCore"]),
        .library(name: "CipStarVideoEngine", targets: ["CipStarVideoEngine"]),
    ],
    targets: [
        .target(name: "CipStarCore"),
        .target(name: "CipStarVideoEngine", dependencies: ["CipStarCore"]),
        .testTarget(name: "CipStarCoreTests", dependencies: ["CipStarCore"]),
    ]
)
