import XCTest
@testable import CipStarCore

final class CoreTests: XCTestCase {
    private func proj(speed: Double = 1) -> Project {
        Project(name: "t", clips: [Clip(mediaFile: "a.mov", sourceDuration: 10, speed: speed)])
    }

    func testSplitKeepsTotalDuration() {
        var p = proj()
        XCTAssertTrue(p.split(at: 4))
        XCTAssertEqual(p.clips.count, 2)
        XCTAssertEqual(p.clips[0].sourceDuration, 4, accuracy: 1e-9)
        XCTAssertEqual(p.clips[1].sourceStart, 4, accuracy: 1e-9)
        XCTAssertEqual(p.duration, 10, accuracy: 1e-9)
    }

    func testSplitWithSpeed() {
        var p = proj(speed: 2)              // 5s on timeline
        XCTAssertTrue(p.split(at: 1))       // 1s timeline = 2s source
        XCTAssertEqual(p.clips[0].sourceDuration, 2, accuracy: 1e-9)
        XCTAssertEqual(p.duration, 5, accuracy: 1e-9)
    }

    func testSplitNearEdgeRejected() {
        var p = proj()
        XCTAssertFalse(p.split(at: 0.01))
        XCTAssertFalse(p.split(at: 9.99))
        XCTAssertEqual(p.clips.count, 1)
    }

    func testTrimHeadAndTail() {
        var p = proj()
        XCTAssertTrue(p.trimHead(at: 3))
        XCTAssertEqual(p.duration, 7, accuracy: 1e-9)
        XCTAssertTrue(p.trimTail(at: 2))
        XCTAssertEqual(p.duration, 2, accuracy: 1e-9)
    }

    func testDuplicateMoveRemove() {
        var p = proj(); p.split(at: 5)
        let first = p.clips[0].id
        let copy = p.duplicate(first)
        XCTAssertEqual(p.clips.count, 3)
        p.move(first, by: 2)
        XCTAssertEqual(p.clips.last?.id, first)
        p.remove(copy!)
        XCTAssertEqual(p.clips.count, 2)
    }

    func testUndoRedo() {
        var p = proj(); var stack = UndoStack<[Clip]>()
        stack.record(p.clips); p.split(at: 5)
        XCTAssertEqual(p.clips.count, 2)
        p.clips = stack.undo(current: p.clips)!
        XCTAssertEqual(p.clips.count, 1)
        p.clips = stack.redo(current: p.clips)!
        XCTAssertEqual(p.clips.count, 2)
    }

    func testRepositoryRoundTripAndCorruptFallback() throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let repo = ProjectRepository(root: dir)
        var p = proj(); p.name = "v1"
        try repo.save(p)
        p.name = "v2"; try repo.save(p)
        XCTAssertEqual(try repo.load(p.id).name, "v2")
        try Data("garbage".utf8).write(to: repo.projectDir(p.id).appendingPathComponent("project.json"))
        XCTAssertEqual(try repo.load(p.id).name, "v1")     // recovered from backup
        XCTAssertEqual(repo.list().count, 1)
        repo.delete(p.id)
        XCTAssertEqual(repo.list().count, 0)
    }
}
