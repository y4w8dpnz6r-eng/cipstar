No third-party dependencies. Apple frameworks only.
