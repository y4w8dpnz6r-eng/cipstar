# Features
## Implemented in code (untested on device/Xcode)
Projects: create/rename/duplicate/delete/search, atomic save, autosave, backup recovery, undo/redo.
Video: import from Photos (copied into project), multi-clip timeline, split, trim to playhead, delete, duplicate, reorder, speed 0.25–4x (pitch-corrected), per-clip volume/mute, preview, pinch zoom, thumbnails, missing-media detection.
Export: H.264/HEVC, MP4/MOV, 720p/1080p/4K, 24/25/30/50/60 fps, progress, cancel, low-storage check, save to Photos, share. No watermark.
UI: EN/AR, RTL, dark/light, haptics.
## NOT implemented yet
Multi-track/overlays, effects (Metal), filters/LUT, transitions, keyframes, text/Arabic typography engine, audio effects & recording, photo editor, plugin formats, AI tools, custom bitrate/ProRes/GIF/HDR, proxy editing, thermal/memory adaptation, UI tests, logo design beyond a simple placeholder icon.
## Limits
Canvas is 16:9 or 9:16 (from first clip). Photos/images are not yet importable. Export uses AVAssetExportSession (no custom bitrate).
