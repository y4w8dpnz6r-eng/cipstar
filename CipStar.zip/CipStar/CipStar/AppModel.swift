import SwiftUI
import CipStarCore

@MainActor
final class AppModel: ObservableObject {
    let repo = ProjectRepository()
    @Published var projects: [Project] = []

    func refresh() { projects = repo.list() }

    func create() -> Project {
        let name = String(localized: "default_project_name") + " \(projects.count + 1)"
        let p = Project(name: name)
        try? repo.save(p)
        refresh()
        return p
    }

    func rename(_ p: Project, to name: String) {
        var q = p; q.name = name; q.modifiedAt = Date()
        try? repo.save(q); refresh()
    }

    func duplicate(_ p: Project) {
        _ = try? repo.duplicate(p.id, newName: p.name + " 2"); refresh()
    }

    func delete(_ p: Project) { repo.delete(p.id); refresh() }
}
