import SwiftUI
import CipStarCore

struct HomeView: View {
    @StateObject private var model = AppModel()
    @State private var path: [UUID] = []
    @State private var renaming: Project?
    @State private var newName = ""
    @State private var search = ""

    private var filtered: [Project] {
        search.isEmpty ? model.projects : model.projects.filter { $0.name.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        NavigationStack(path: $path) {
            List {
                Section {
                    Button {
                        Haptics.tap()
                        path.append(model.create().id)
                    } label: {
                        Label("new_video_project", systemImage: "plus.rectangle.on.rectangle")
                            .font(.headline).padding(.vertical, 10)
                    }
                }
                Section("projects") {
                    if filtered.isEmpty {
                        Text("empty_projects").foregroundStyle(.secondary)
                    }
                    ForEach(filtered) { p in
                        NavigationLink(value: p.id) { row(p) }
                            .contextMenu {
                                Button("rename") { newName = p.name; renaming = p }
                                Button("duplicate") { model.duplicate(p) }
                                Button("delete", role: .destructive) { model.delete(p) }
                            }
                            .swipeActions { Button("delete", role: .destructive) { model.delete(p) } }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Theme.bg)
            .navigationTitle("CipStar")
            .searchable(text: $search)
            .navigationDestination(for: UUID.self) { id in
                if let p = model.projects.first(where: { $0.id == id }) {
                    EditorView(project: p, repo: model.repo)
                }
            }
            .onAppear { model.refresh() }
            .alert("rename", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                TextField("", text: $newName)
                Button("save") { if let p = renaming, !newName.isEmpty { model.rename(p, to: newName) } }
                Button("cancel", role: .cancel) {}
            }
        }
    }

    private func row(_ p: Project) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(p.name).font(.headline)
            Text("\(TimeFormat.timecode(p.duration)) · \(String(format: String(localized: "clips_fmt"), p.clips.count)) · \(p.modifiedAt.formatted(.relative(presentation: .named)))")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
}
