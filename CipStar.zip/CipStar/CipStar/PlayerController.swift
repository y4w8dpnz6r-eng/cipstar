import AVFoundation
import Combine
import CipStarCore
import CipStarVideoEngine

@MainActor
final class PlayerController: ObservableObject {
    let player = AVPlayer()
    @Published var currentTime: Double = 0
    @Published var isPlaying = false
    @Published var missingCount = 0
    private var observer: Any?
    private var buildTask: Task<Void, Never>?

    init() {
        observer = player.addPeriodicTimeObserver(forInterval: CMTime(value: 1, timescale: 30), queue: .main) { [weak self] t in
            MainActor.assumeIsolated { self?.currentTime = t.seconds.isFinite ? t.seconds : 0 }
        }
        player.publisher(for: \.timeControlStatus)
            .map { $0 != .paused }
            .receive(on: DispatchQueue.main)
            .assign(to: &$isPlaying)
    }

    func rebuild(project: Project, repo: ProjectRepository) {
        buildTask?.cancel()
        let resume = currentTime
        let wasPlaying = isPlaying
        buildTask = Task {
            do {
                let built = try await CompositionBuilder.build(
                    project: project,
                    mediaURL: { repo.mediaURL(projectID: project.id, file: $0.mediaFile) },
                    longSide: 1280, frameRate: 30)
                guard !Task.isCancelled else { return }
                missingCount = built?.missingClipIDs.count ?? 0
                guard let built else { player.replaceCurrentItem(with: nil); currentTime = 0; return }
                let item = AVPlayerItem(asset: built.composition)
                item.videoComposition = built.videoComposition
                item.audioMix = built.audioMix
                item.audioTimePitchAlgorithm = .spectral
                player.replaceCurrentItem(with: item)
                _ = await player.seek(to: CMTime(seconds: min(resume, built.duration), preferredTimescale: 600),
                                      toleranceBefore: .zero, toleranceAfter: .zero)
                if wasPlaying { player.play() }
            } catch {
                guard !Task.isCancelled else { return }
                player.replaceCurrentItem(with: nil)
                missingCount = project.clips.count
            }
        }
    }

    func seek(_ t: Double) {
        player.seek(to: CMTime(seconds: t, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
    }

    func toggle(duration: Double) {
        if isPlaying { player.pause() } else {
            if currentTime >= duration - 0.05 { seek(0) }
            player.play()
        }
    }

    func pause() { player.pause() }
}
