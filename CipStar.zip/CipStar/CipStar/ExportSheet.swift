import SwiftUI
import Photos
import CipStarCore
import CipStarVideoEngine

struct ExportSheet: View {
    @ObservedObject var model: EditorModel
    @Environment(\.dismiss) private var dismiss

    enum Phase: Equatable { case idle, running, done(URL), failed(String) }
    @State private var settings = ExportSettings()
    @State private var phase: Phase = .idle
    @State private var progress = 0.0
    @State private var savedToPhotos = false
    @State private var exporter = VideoExporter()

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("resolution", selection: $settings.resolution) {
                        ForEach(ExportSettings.Resolution.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                    Picker("frame_rate", selection: $settings.fps) {
                        ForEach(ExportSettings.frameRates, id: \.self) { Text(verbatim: "\($0) FPS").tag($0) }
                    }
                    Picker("codec", selection: $settings.codec) {
                        ForEach(ExportSettings.Codec.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                    Picker("format", selection: $settings.container) {
                        ForEach(ExportSettings.Container.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                }
                .disabled(phase == .running)

                Section {
                    switch phase {
                    case .idle:
                        Button("start_export") { start() }.bold()
                    case .running:
                        ProgressView(value: progress) { Text("\(Int(progress * 100))%").monospacedDigit() }
                        Button("cancel_export", role: .destructive) { exporter.cancel() }
                    case .done(let url):
                        Button(savedToPhotos ? "saved_to_photos" : "save_to_photos") { Task { await saveToPhotos(url) } }
                            .disabled(savedToPhotos)
                        ShareLink(item: url) { Label("share", systemImage: "square.and.arrow.up") }
                    case .failed(let msg):
                        Text(msg).foregroundStyle(.red)
                        Button("start_export") { start() }
                    }
                }
            }
            .navigationTitle("export_title")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("done") { dismiss() }.disabled(phase == .running) } }
            .interactiveDismissDisabled(phase == .running)
        }
    }

    private func start() {
        guard StorageMonitor.availableBytes() > 300_000_000 else {
            phase = .failed(String(localized: "low_storage")); Haptics.error(); return
        }
        phase = .running; progress = 0; savedToPhotos = false
        let project = model.project
        let repo = model.repo
        let settings = settings
        let exporter = exporter
        Task {
            do {
                let url = try await exporter.export(
                    project: project,
                    mediaURL: { repo.mediaURL(projectID: project.id, file: $0.mediaFile) },
                    settings: settings,
                    progress: { p in Task { @MainActor in progress = p } })
                phase = .done(url); Haptics.success()
            } catch ExportError.cancelled {
                phase = .idle
            } catch {
                phase = .failed(error.localizedDescription); Haptics.error()
            }
        }
    }

    private func saveToPhotos(_ url: URL) async {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else {
            phase = .failed(String(localized: "photos_denied")); return
        }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
            }
            savedToPhotos = true; Haptics.success()
        } catch { phase = .failed(error.localizedDescription) }
    }
}
