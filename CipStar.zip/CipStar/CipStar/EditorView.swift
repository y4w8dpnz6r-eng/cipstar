import SwiftUI
import PhotosUI
import AVFoundation
import CipStarCore

struct PlayerView: UIViewRepresentable {
    let player: AVPlayer
    func makeUIView(context: Context) -> PlayerUIView {
        let v = PlayerUIView()
        v.playerLayer.player = player
        v.playerLayer.videoGravity = .resizeAspect
        return v
    }
    func updateUIView(_ uiView: PlayerUIView, context: Context) {}
}

final class PlayerUIView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

enum Thumbs {
    static func image(_ url: URL, at seconds: Double) async -> UIImage? {
        let gen = AVAssetImageGenerator(asset: AVURLAsset(url: url))
        gen.appliesPreferredTrackTransform = true
        gen.maximumSize = CGSize(width: 240, height: 240)
        guard let r = try? await gen.image(at: CMTime(seconds: seconds, preferredTimescale: 600)) else { return nil }
        return UIImage(cgImage: r.image)
    }
}

struct ClipBlock: View {
    let clip: Clip, url: URL, selected: Bool
    @State private var image: UIImage?
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Rectangle().fill(Theme.surface)
            if let image { Image(uiImage: image).resizable().scaledToFill().opacity(0.7) }
            if clip.speed != 1 || clip.volume == 0 {
                HStack(spacing: 4) {
                    if clip.speed != 1 { Text(verbatim: "\(clip.speed.formatted())×") }
                    if clip.volume == 0 { Image(systemName: "speaker.slash.fill") }
                }
                .font(.caption2.bold()).padding(3).background(.black.opacity(0.6)).foregroundStyle(.white)
            }
        }
        .clipped()
        .overlay(Rectangle().stroke(selected ? Theme.accent : Color.black, lineWidth: selected ? 3 : 1))
        .task(id: clip.sourceStart) { image = await Thumbs.image(url, at: clip.sourceStart) }
    }
}

struct ToolLabel: View {
    let key: LocalizedStringKey, icon: String
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon).font(.title3)
            Text(key).font(.caption2).lineLimit(1)
        }
        .frame(minWidth: 56).padding(.vertical, 6)
    }
}

struct EditorView: View {
    @StateObject private var model: EditorModel
    @State private var picked: [PhotosPickerItem] = []
    @State private var showExport = false
    @State private var zoom: CGFloat = 1
    @GestureState private var pinch: CGFloat = 1
    @Environment(\.scenePhase) private var scenePhase

    init(project: Project, repo: ProjectRepository) {
        _model = StateObject(wrappedValue: EditorModel(project: project, repo: repo))
    }

    private var pxPerSec: CGFloat { 40 * zoom * pinch }
    private var hasSelection: Bool { model.selection != nil }
    private var duration: Double { max(model.project.duration, 0.01) }

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                Color.black
                PlayerView(player: model.player.player)
                if model.isImporting { ProgressView().tint(.white) }
                if model.project.clips.isEmpty && !model.isImporting {
                    Text("empty_timeline").foregroundStyle(.white.opacity(0.7))
                }
            }
            .frame(maxHeight: .infinity)

            if model.player.missingCount > 0 {
                Text(String(format: String(localized: "missing_media_fmt"), model.player.missingCount))
                    .font(.caption).padding(6).frame(maxWidth: .infinity).background(.orange.opacity(0.9)).foregroundStyle(.black)
            }
            transport
            timeline
            toolbar
        }
        .background(Theme.bg)
        .navigationTitle(model.project.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("export") { model.player.pause(); showExport = true }
                    .disabled(model.project.clips.isEmpty).bold()
            }
        }
        .sheet(isPresented: $showExport) { ExportSheet(model: model) }
        .onChange(of: picked) { _, items in
            guard !items.isEmpty else { return }
            Task { await model.importItems(items); picked = [] }
        }
        .onChange(of: scenePhase) { _, p in if p != .active { model.flush() } }
        .onDisappear { model.flush(); model.player.pause() }
        .alert("error", isPresented: Binding(get: { model.errorMessage != nil },
                                             set: { if !$0 { model.errorMessage = nil } })) {
            Button("ok", role: .cancel) {}
        } message: { Text(model.errorMessage ?? "") }
    }

    private var transport: some View {
        HStack(spacing: 12) {
            Button { Haptics.tap(); model.player.toggle(duration: model.project.duration) } label: {
                Image(systemName: model.player.isPlaying ? "pause.fill" : "play.fill").font(.title2).frame(width: 36)
            }
            Text(TimeFormat.timecode(model.player.currentTime)).font(.caption.monospacedDigit())
            Slider(value: Binding(get: { min(model.player.currentTime, duration) },
                                  set: { model.player.seek($0) }), in: 0...duration)
            Text(TimeFormat.timecode(model.project.duration)).font(.caption.monospacedDigit()).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 12).padding(.vertical, 6)
        .environment(\.layoutDirection, .leftToRight)
    }

    private var timeline: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            ZStack(alignment: .leading) {
                HStack(spacing: 0) {
                    ForEach(model.project.clips) { clip in
                        ClipBlock(clip: clip, url: model.url(for: clip), selected: model.selection == clip.id)
                            .frame(width: max(24, CGFloat(clip.timelineDuration) * pxPerSec), height: 64)
                            .onTapGesture { Haptics.tap(); model.selection = clip.id }
                    }
                }
                Rectangle().fill(.white).frame(width: 2, height: 76)
                    .offset(x: CGFloat(model.player.currentTime) * pxPerSec)
            }
            .padding(.horizontal, 12)
        }
        .frame(height: 84)
        .background(Color.black.opacity(0.25))
        .environment(\.layoutDirection, .leftToRight)   // timelines always run left to right
        .gesture(MagnifyGesture()
            .updating($pinch) { v, s, _ in s = v.magnification }
            .onEnded { v in zoom = min(max(zoom * v.magnification, 0.25), 8) })
    }

    private var toolbar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 4) {
                PhotosPicker(selection: $picked, matching: .videos) { ToolLabel(key: "add_clip", icon: "plus.rectangle.on.rectangle") }
                tool("split", "scissors", enabled: !model.project.clips.isEmpty) { model.splitAtPlayhead() }
                Menu {
                    Button("trim_head") { model.trimHead() }
                    Button("trim_tail") { model.trimTail() }
                } label: { ToolLabel(key: "trim", icon: "crop") }.disabled(model.project.clips.isEmpty)
                Menu {
                    ForEach([0.25, 0.5, 1, 1.5, 2, 4], id: \.self) { s in
                        Button { model.setSpeed(s) } label: { Text(verbatim: "\(s.formatted())×") }
                    }
                } label: { ToolLabel(key: "speed", icon: "speedometer") }.disabled(!hasSelection)
                Menu {
                    Button("volume_full") { model.setVolume(1) }
                    Button("volume_half") { model.setVolume(0.5) }
                    Button("mute") { model.setVolume(0) }
                } label: { ToolLabel(key: "volume", icon: "speaker.wave.2") }.disabled(!hasSelection)
                tool("duplicate", "plus.square.on.square", enabled: hasSelection) { model.duplicateSelected() }
                tool("move_back", "arrow.left.square", enabled: hasSelection) { model.moveSelected(-1) }
                tool("move_forward", "arrow.right.square", enabled: hasSelection) { model.moveSelected(1) }
                tool("delete", "trash", enabled: hasSelection) { model.deleteSelected() }
                tool("undo", "arrow.uturn.backward", enabled: model.canUndo) { model.undo() }
                tool("redo", "arrow.uturn.forward", enabled: model.canRedo) { model.redo() }
            }
            .padding(.horizontal, 8)
        }
        .padding(.bottom, 4)
        .environment(\.layoutDirection, .leftToRight)
    }

    private func tool(_ key: LocalizedStringKey, _ icon: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) { ToolLabel(key: key, icon: icon) }.disabled(!enabled)
    }
}
