import SwiftUI

@main
struct CipStarApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView().tint(Theme.accent)
        }
    }
}
