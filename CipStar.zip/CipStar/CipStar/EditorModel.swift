import SwiftUI
import PhotosUI
import AVFoundation
import CipStarCore
import CipStarVideoEngine

struct PickedMovie: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { m in
            SentTransferredFile(m.url)
        } importing: { received in
            let dest = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString).appendingPathExtension(received.file.pathExtension)
            try FileManager.default.copyItem(at: received.file, to: dest)
            return PickedMovie(url: dest)
        }
    }
}

@MainActor
final class EditorModel: ObservableObject {
    @Published var project: Project
    @Published var selection: UUID?
    @Published var isImporting = false
    @Published var errorMessage: String?
    let repo: ProjectRepository
    let player = PlayerController()
    private var history = UndoStack<[Clip]>()
    private var saveTask: Task<Void, Never>?

    var canUndo: Bool { history.canUndo }
    var canRedo: Bool { history.canRedo }

    init(project: Project, repo: ProjectRepository) {
        self.project = project; self.repo = repo
        player.rebuild(project: project, repo: repo)
    }

    func url(for clip: Clip) -> URL { repo.mediaURL(projectID: project.id, file: clip.mediaFile) }

    private func mutate(_ change: (inout Project) -> Void) {
        history.record(project.clips)
        change(&project)
        didChange()
    }

    private func didChange() {
        project.modifiedAt = Date()
        if let s = selection, !project.clips.contains(where: { $0.id == s }) { selection = nil }
        scheduleSave()
        player.rebuild(project: project, repo: repo)
        objectWillChange.send()
    }

    private func scheduleSave() {
        saveTask?.cancel()
        saveTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 500_000_000)
            guard !Task.isCancelled, let self else { return }
            self.flush()
        }
    }

    func flush() {
        saveTask?.cancel()
        do { try repo.save(project) } catch { errorMessage = error.localizedDescription }
    }

    // MARK: Editing actions
    func undo() { if let prev = history.undo(current: project.clips) { project.clips = prev; didChange() } }
    func redo() { if let next = history.redo(current: project.clips) { project.clips = next; didChange() } }

    func splitAtPlayhead() {
        let t = player.currentTime
        guard project.locate(t) != nil else { return }
        var probe = project
        guard probe.split(at: t) else { Haptics.error(); return }
        mutate { $0.split(at: t) }; Haptics.tap()
    }
    func trimHead() { let t = player.currentTime; mutate { $0.trimHead(at: t) }; Haptics.tap() }
    func trimTail() { let t = player.currentTime; mutate { $0.trimTail(at: t) }; Haptics.tap() }
    func deleteSelected() { guard let id = selection else { return }; mutate { $0.remove(id) }; Haptics.tap() }
    func duplicateSelected() { guard let id = selection else { return }; mutate { $0.duplicate(id) }; Haptics.tap() }
    func moveSelected(_ d: Int) { guard let id = selection else { return }; mutate { $0.move(id, by: d) }; Haptics.tap() }
    func setSpeed(_ s: Double) { guard let id = selection else { return }; mutate { $0.setSpeed(id, s) } }
    func setVolume(_ v: Double) { guard let id = selection else { return }; mutate { $0.setVolume(id, v) } }

    // MARK: Import
    func importItems(_ items: [PhotosPickerItem]) async {
        isImporting = true
        defer { isImporting = false }
        for item in items {
            do {
                guard let movie = try await item.loadTransferable(type: PickedMovie.self) else { continue }
                defer { try? FileManager.default.removeItem(at: movie.url) }
                let file = try repo.importMedia(from: movie.url, projectID: project.id)
                let stored = repo.mediaURL(projectID: project.id, file: file)
                let d = try await AVURLAsset(url: stored).load(.duration).seconds
                guard d.isFinite, d > 0 else {
                    try? FileManager.default.removeItem(at: stored)
                    throw CocoaError(.fileReadCorruptFile)
                }
                mutate { $0.clips.append(Clip(mediaFile: file, sourceDuration: d)) }
            } catch {
                errorMessage = String(localized: "import_failed")
                Haptics.error()
            }
        }
    }
}
