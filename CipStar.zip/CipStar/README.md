# CipStar (v0.1 — Phase 1+2)
Native iOS 17+ video editor (SwiftUI + AVFoundation). iPhone & iPad. No server, no account, no ads, no watermark.

**Status: source code written WITHOUT access to Xcode. It has NOT been compiled or run.** Expect to fix a few compile errors on first build (see BUILD_GUIDE.md).

Quick start: `brew install xcodegen && xcodegen generate && open CipStar.xcodeproj`
