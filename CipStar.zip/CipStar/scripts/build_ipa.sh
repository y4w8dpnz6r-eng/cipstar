#!/bin/bash
# Usage: ./scripts/build_ipa.sh YOUR_TEAM_ID
set -e
TEAM="$1"; [ -z "$TEAM" ] && { echo "Usage: $0 TEAM_ID"; exit 1; }
xcodegen generate
xcodebuild archive -project CipStar.xcodeproj -scheme CipStar -configuration Release \
  -destination 'generic/platform=iOS' -archivePath build/CipStar.xcarchive \
  DEVELOPMENT_TEAM="$TEAM" -allowProvisioningUpdates
cat > build/ExportOptions.plist <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>method</key><string>development</string>
<key>teamID</key><string>$TEAM</string>
</dict></plist>
PLIST
xcodebuild -exportArchive -archivePath build/CipStar.xcarchive -exportPath build/ipa \
  -exportOptionsPlist build/ExportOptions.plist -allowProvisioningUpdates
echo "IPA: build/ipa/CipStar.ipa"
